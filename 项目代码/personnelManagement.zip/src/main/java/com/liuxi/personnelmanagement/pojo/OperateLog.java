package com.liuxi.personnelmanagement.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author 蒲月理想
 */
// @Data 作用：交给IOC容器管理，
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OperateLog {
    //日志ID
    private Integer id;
    //操作人ID
    private Integer operateUser;
    private LocalDateTime operateTime;
    //操作类名
    private String className;
    //操作方法名
    private String methodName;
    // 操作方法参数
    private String methodParams;
    //操作方法返回值
    private String returnValue;
    // 操作耗时
    private Long costTime;
}
