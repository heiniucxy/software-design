package com.liuxi.personnelmanagement.anno;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author 蒲月理想
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Log {
    // 加上@interface的作用：
    // 1. 使代码更规范，更清晰
    // 2. 使代码更易于维护

}
