package com.liuxi.personnelmanagement.service.impl;

import com.liuxi.personnelmanagement.mapper.DeptLogMapper;
import com.liuxi.personnelmanagement.mapper.DeptMapper;
import com.liuxi.personnelmanagement.mapper.EmpMapper;
import com.liuxi.personnelmanagement.pojo.Dept;
import com.liuxi.personnelmanagement.pojo.DeptLog;
import com.liuxi.personnelmanagement.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author 蒲月理想
 */
@Service
public class DeptServiceImpl implements DeptService {

    private final DeptMapper deptMapper;
    private final EmpMapper empMapper;
    private  final DeptLogMapper deptLogMapper;
    @Autowired
    public  DeptServiceImpl(DeptMapper deptMapper, EmpMapper empMapper, DeptLogMapper deptLogMapper) {
      this.deptMapper = deptMapper;
      this.empMapper = empMapper;
        this.deptLogMapper = deptLogMapper;
    }
  /*
  // 改用上述更加安全的注入字段方式
  @Autowired
    private DeptMapper deptMapper;

    @Autowired
    private EmpMapper empMapper;
    */
    @Override
    public List<Dept> list() {
        return deptMapper.list();
    }

    /**
     * 根据ID查询部门
     * @param id
     * @return
     */
    @Override
    public Dept getDeptById(Integer id) {
        return deptMapper.getByDeptId(id);
    }


    // @Transactional 开启事务管理——spring框架,并且指定所有异常都回滚
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(Integer id) {
        try
        {
            // 删除部门
            deptMapper.deleteById(id);
            // 部门下的员工也会被删除
            empMapper.deleteByDeptId(id);
        }finally {
            DeptLog deptLog = new DeptLog();
            deptLog.setCreateTime(LocalDateTime.now());
            deptLog.setDescription("此次操作为解散部门，解散的部门ID为"+id);
            deptLogMapper.insert(deptLog);
        }

    }

    /**
     * 添加部门
     * @param dept
     */
    @Override
    public void add(Dept dept) {
        dept.setCreateTime(LocalDateTime.now());
        dept.setUpdateTime(LocalDateTime.now());

        deptMapper.insert(dept);
    }

    /**
     * 更新部门
     * @param dept
     */
    @Override
    public void update(Dept dept) {
        dept.setUpdateTime(LocalDateTime.now());
        deptMapper.updateById(dept);
    }

    @Override
    public List<Dept> numberOfDepartmentEmployees() {
       // 查询部门人数
        return deptMapper.numberOfDepartmentEmployees();
    }
    // 查询部门薪资情况
    @Override
    public List<Dept> getDeptSalary() {
        return deptMapper.getDeptSalary();
    }

    // 查询部门名称是否存在
    @Override
    public Dept findByName(String name) {
        return deptMapper.findByName(name);
    }

    @Override
    public Dept getByName(String name) {
        return deptMapper.getByName(name);
    }

}
