package com.liuxi.personnelmanagement.mapper;


import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.Empcredentialsview;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 蒲月理想
* @description 针对表【empcredentialsview】的数据库操作Mapper
* @createDate 2024-06-04 17:44:40
* @Entity generator.domain.Empcredentialsview
*/
@Mapper
public interface EmpcredentialsviewMapper {

    // 更新用户信息
    void update(Empcredentialsview emp);
    // 用户登录
    Emp login(Empcredentialsview emp);
}




