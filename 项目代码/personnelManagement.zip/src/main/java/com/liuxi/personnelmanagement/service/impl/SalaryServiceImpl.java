package com.liuxi.personnelmanagement.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.liuxi.personnelmanagement.mapper.SalaryMapper;
import com.liuxi.personnelmanagement.pojo.Salary;
import com.liuxi.personnelmanagement.pojo.PageBean;
import com.liuxi.personnelmanagement.service.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author 蒲月理想
 */
@Service
public class SalaryServiceImpl implements SalaryService {
    private final SalaryMapper salaryMapper;

    @Autowired
    public SalaryServiceImpl(SalaryMapper salaryMapper) {
        this.salaryMapper = salaryMapper;
    }

    /**
     * 分页查询工资
     * @param page
     * @param pageSize
     * @param name
     * @param gender
     * @param totalSalary
     * @return
     */
    @Override
    public PageBean page(Integer page, Integer pageSize, String name, Short gender, Double totalSalary) {
        //1. 设置分页参数
        System.out.println("page = " + page + ", pageSize = " + pageSize);
        PageHelper.startPage(page,pageSize);
        // 测试查看
        System.out.println("name = " + name + ", gender = " + gender + ", totalSalary = " + totalSalary);
        //2. 执行查询
        List<Salary> salaryList = salaryMapper.list(name, gender,totalSalary);
        Page<Salary> p = (Page<Salary>) salaryList;

        //3. 封装PageBean对象
        return new PageBean(p.getTotal(), p.getResult());
    }

    /**
     * 查询工资
     * @param id
     * @return
     */
    @Override
    public Salary getSalaryById(Integer id) {
     return salaryMapper.getSalaryById(id);

       }

    /**
     * 更新工资
     * @param salary
     */
    @Override
    public void update(Salary salary) {
       salary.setUpdateTime(LocalDateTime.now());
        salaryMapper.updateById(salary);
    }

    /**
     * 插入薪资数据——新员工加入的时候
     */
    @Override
    public void save(short job,Integer id) {
        Salary salary = new Salary();
        salary.setJob(job);
        salary.setEmpId(id);
        System.out.println("id: " + id);
        // 十个职位，为其设定基础工资
//        if(job == 1)
//        {
//        }
//        if(job == 2)
//        {
//
//        }
//        if(job ==3)
//        {
//
//        }
//        if(job == 4)
//        {
//
//        }
//        if(job == 5)
//        {
//
//        }
//        if(job == 6)
//        {
//
//        }
//        if(job == 7)
//        {
//
//        }
//        if(job == 8)
//        {
//
//        }
//        if(job == 9)
//        {
//
//        }
//        if(job == 10)
//        {
//        }
        salary.setBasicSalary((double) (100000 - (job-1) * 10000));
        salary.setMeritSalary((0.0));
        salary.setBonusSalary((0.0));
        salary.setSubsidySalary((0.0));
        salary.setCreateTime(LocalDateTime.now());
        salary.setUpdateTime(LocalDateTime.now());
        // 测试，输出数据
        //System.out.println(salary);
        salaryMapper.save(salary);
    }

    /**
     * 查询所有的薪资
     * @return
     */
    @Override
    public List<Salary> getAllSalary() {
        return salaryMapper.getAllSalary();
    }


}
