package com.liuxi.personnelmanagement.mapper;

import com.liuxi.personnelmanagement.pojo.Emp;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 员工管理
 * @author 蒲月理想
 */
@Mapper
public interface EmpMapper {

    /**
     * 查询总记录数
     * @return
     */
    //@Select("select count(*) from emp")
    //public Long count();

    /**
     * 分页查询,获取列表数据
     * @param start
     * @param pageSize
     * @return
     */
    //@Select("select * from emp limit #{start},#{pageSize}")
    //public List<Emp> page(Integer start, Integer pageSize);

    /**
     * 员工信息查询
     * @return
     */
    //@Select("select * from emp")
    List<Emp> list(@Param("name") String name,
                   @Param("gender") Short gender,
                   @Param("maritalStatus") Short maritalStatus,
                   @Param("employeeStatus") Short employeeStatus,
                   @Param("job") Short job,
                   @Param("deptId") Integer deptId,
                   @Param("begin") LocalDate begin,
                   @Param("end") LocalDate end);

    /**
     * 批量删除，确保参数传递正确，使用@Param注解
     * @param ids
     */
    void delete(@Param("ids") List<Integer> ids);

    /**
     * 新增员工
     * @param emp
     */
//    @Insert("insert into emp(username, name, gender, image, job, entrydate, dept_id, create_time, update_time) " +
//            " values(#{username},#{name},#{gender},#{image},#{job},#{entrydate},#{deptId},#{createTime},#{updateTime})")
    void insert(Emp emp);

    /**
     * 根据ID查询员工
     * @param id
     * @return
     */
    @Select("select * from emp where  id = #{id}")
    Emp getById(Integer id);

    /**
     * 更新员工
     * @param emp
     */
    void update(Emp emp);

    /**
     * 根据用户名和密码查询员工
     * @param emp
     * @return
     */
    @Select("select * from emp where username = #{username} and password = #{password}")
    Emp getByUsernameAndPassword(Emp emp);

    @Delete("delete from emp where dept_id = #{deptId}")
    void deleteByDeptId(Integer deptId);

    // 统计男女的数目
    @Select("select gender,count(*) as genderNumber from emp group by gender")
    List<Emp> getGenderNumber();

    // 查询用户名是否重复
    @Select("select * from emp where username = #{username}")
    Emp findByUsername(String username);

    /**
     * 根据用户姓名和用户名查询用户
     * @param emp
     * @return
     */
    @Select("select * from emp where username = #{username} and name = #{name}")
    Emp selectByName(Emp emp);
}
