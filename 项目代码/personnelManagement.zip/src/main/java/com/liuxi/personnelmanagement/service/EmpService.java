package com.liuxi.personnelmanagement.service;

import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.PageBean;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 员工管理
 * @author 蒲月理想
 */
public interface EmpService {
    /**
     * 分页查询
     * @param page
     * @param pageSize
     * @return
     */
    PageBean page(Integer page, Integer pageSize, String name, Short gender, Short maritalStatus, Short employeeStatus, Short job, Integer deptId, LocalDate begin,LocalDate end);

    /**
     * 批量删除
     * @param ids
     */
    void delete(List<Integer> ids);

    /**
     * 新增员工
     * @param emp
     */
    int save(Emp emp);

    /**
     * 根据ID查询部门
     * @param id
     * @return emp
     */
    Emp getById(Integer id);

    /**
     * 更新员工
     * @param emp
     */
    void update(Emp emp);

    /**
     * 员工登录
     * @param emp
     * @return Emp
     */
    Emp login(Emp emp);

    /**
     * 查询员工男女性别分布
     * @return
     */
    List<Emp> getGenderNumber();


    Emp findByUsername(String username);

    Emp selectByName(Emp emp);
}
