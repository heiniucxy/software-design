package com.liuxi.personnelmanagement.controller;

import com.liuxi.personnelmanagement.anno.Log;
import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.PageBean;
import com.liuxi.personnelmanagement.pojo.Result;
import com.liuxi.personnelmanagement.service.EmpService;
import com.liuxi.personnelmanagement.service.SalaryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/**
 * 员工管理Controller
 * @author 蒲月理想
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/emps")
public class EmpController {

    private final EmpService empService;
    private final SalaryService salaryService;
    // 使用构造器注入 或者使用lombok的注解
//    @Autowired
//    public EmpController(EmpService empService) {
//        this.empService = empService;
//    }

    @GetMapping
    public Result page(@RequestParam(defaultValue = "1") Integer page,
                       @RequestParam(defaultValue = "10") Integer pageSize,
                       String name, Short gender,Short maritalStatus,
                       Short employeeStatus,Short job,Integer deptId,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate begin,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate end){

        log.info("分页查询, 参数: {},{}, {}, {}, {}, {}, {}, {},{},{}",page,pageSize,name,gender,maritalStatus,employeeStatus,job,deptId,begin,end);
        /* 调用service分页查询 */
        PageBean pageBean = empService.page(page,pageSize,name,gender,maritalStatus,employeeStatus,job,deptId,begin,end);
        log.info("Service查询结果: {}",pageBean);
        return Result.success(pageBean);
    }
    @Log
    @DeleteMapping("/{ids}")
    public Result delete(@PathVariable List<Integer> ids){
        // 打印查看员工列表ID
        log.info("批量删除操作, ids:{}",ids);
        empService.delete(ids);
        return Result.success();
    }
    @Log
    @PostMapping
    public Result save(@RequestBody Emp emp){
        log.info("新增员工, emp: {}", emp);
        // 首先查询用户名是否重复
        Emp isExist = empService.findByUsername(emp.getUsername());
        if(isExist != null){
            return Result.error("用户名已存在,请更换用户名");
        }
        int id = empService.save(emp);
        //System.out.println("刚刚新插入的id: "+id);
        salaryService.save(emp.getJob(),id);
        return Result.success();
    }
    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        // 打印查看员工列表ID
        log.info("根据ID查询员工信息, id: {}",id);
        Emp emp = empService.getById(id);
        emp.setPassword("");
        return Result.success(emp);
    }
    // 更新员工信息
    @Log
    @PutMapping
    public Result update(@RequestBody Emp emp){
        log.info("更新员工信息 : {}", emp);
        // 查询用户名是否已经存在
        Emp isExist = empService.findByUsername(emp.getUsername());
        if(isExist != null && !Objects.equals(isExist.getId(), emp.getId())){
            return Result.error("用户名已存在,请更换用户名");
        }

        empService.update(emp);
        return Result.success();
    }
    // 修改用户权限：
    @Log
    @PutMapping("/authority")
    public Result updateAuthority(@RequestBody Emp emp){
        log.info("更新员工权限 : {}",emp);
        // 查询用户名是否已经存在
        Emp isExist = empService.findByUsername(emp.getUsername());
        if(isExist != null && !Objects.equals(isExist.getId(), emp.getId())){
            return Result.error("用户名已存在,请更换用户名");
        }

        empService.update(emp);
        return Result.success();
    }
}





