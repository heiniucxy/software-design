package com.liuxi.personnelmanagement.controller;

import com.liuxi.personnelmanagement.anno.Log;
import com.liuxi.personnelmanagement.pojo.Salary;
import com.liuxi.personnelmanagement.pojo.PageBean;
import com.liuxi.personnelmanagement.pojo.Result;
import com.liuxi.personnelmanagement.service.SalaryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
/**
 * @author 蒲月理想
 */
@Slf4j
@RestController
@RequestMapping("/salary")
public class SalaryController {
    private final SalaryService salaryService;

    @Autowired
    public SalaryController(SalaryService salaryService) {
        this.salaryService = salaryService;
    }
    /**
     * 查询所有工资信息
     *
     * @return
     */
    @GetMapping
    public Result page(@RequestParam(defaultValue = "1") Integer page,
                       @RequestParam(defaultValue = "10") Integer pageSize,
                       String name, Short gender,Double totalSalary){
        log.info("分页查询工资, 参数: {},{},{},{},{}",page,pageSize,name,gender,totalSalary);
        //调用service分页查询
        PageBean pageBean = salaryService.page(page,pageSize,name,gender,totalSalary);
        // 查看数据：
        System.out.println("pageBean = "+ pageBean);
        return Result.success(pageBean);
    }
    /**
     * 根据Id查询工资
     * {},
     */
    @GetMapping("/{id}")
    public Result getBySalaryId(@PathVariable Integer id){
        log.info("根据empId查询工资: {}",id);
        //调用service查询工资
        Salary salary = salaryService.getSalaryById(id);
       // System.out.println("salary = "+salary);
        return Result.success(salary);
    }
    /**
     * 修改工资信息
     * @return result
     */
    @Log
    @PutMapping
    public Result update(@RequestBody Salary salary){

        log.info("修改工资: {}" , salary);
        //调用service修改工资
        salaryService.update(salary);
        return Result.success();
    }

}
