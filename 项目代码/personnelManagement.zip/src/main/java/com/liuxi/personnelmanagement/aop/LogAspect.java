package com.liuxi.personnelmanagement.aop;

import com.alibaba.fastjson.JSONObject;
import com.liuxi.personnelmanagement.mapper.OperateLogMapper;
import com.liuxi.personnelmanagement.pojo.OperateLog;
import com.liuxi.personnelmanagement.utils.JwtUtils;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
//java.
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Arrays;

/**
 * @author 蒲月理想
 */
@Slf4j
@Component
@Aspect
public class LogAspect {

    private final HttpServletRequest httpServletRequest;
    private final OperateLogMapper operateLogMapper;


    public LogAspect(HttpServletRequest httpServletRequest, OperateLogMapper operateLogMapper) {
        this.httpServletRequest = httpServletRequest;
        this.operateLogMapper = operateLogMapper;
    }
    @Around("@annotation(com.liuxi.personnelmanagement.anno.Log)")
    public Object recordLog(ProceedingJoinPoint joinPoint) throws Throwable {
        //操作人ID - 当前登录员工ID
        //获取请求头中的jwt令牌, 解析令牌
        String jwt = httpServletRequest.getHeader("token");
        Claims claims = JwtUtils.parseJWT(jwt);
        Integer operateUser = (Integer) claims.get("id");

        //操作时间
        LocalDateTime operateTime = LocalDateTime.now();

        //操作类名
        String className = joinPoint.getTarget().getClass().getName();

        //操作方法名
        String methodName = joinPoint.getSignature().getName();

        //操作方法参数
        Object[] args = joinPoint.getArgs();
        String methodParams = Arrays.toString(args);

        // 起始时间
        long begin = System.currentTimeMillis();
        //调用原始目标方法运行
        Object result = joinPoint.proceed();

        //结束时间
        long end = System.currentTimeMillis();

        //方法返回值
        String returnValue = JSONObject.toJSONString(result);

        //操作耗时
        Long costTime = end - begin;


        //记录操作日志
        OperateLog operateLog = new OperateLog(null,operateUser,operateTime,className,methodName,methodParams,returnValue,costTime);
        operateLogMapper.insert(operateLog);

        log.info("AOP记录操作日志: {}" , operateLog);

        return result;
    }
}
