package com.liuxi.personnelmanagement.service.impl;

import com.liuxi.personnelmanagement.mapper.DeptLogMapper;
import com.liuxi.personnelmanagement.pojo.DeptLog;
import com.liuxi.personnelmanagement.service.DeptLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author 蒲月理想
 */
@Service
public class DeptLogServiceImpl implements DeptLogService {

    private final DeptLogMapper deptLogMapper;

    // @Autowired 的作用是：
    // 自动装配通过类型，如果存在多个同一类型的bean，再通过属性名进行装配。
    // 如果不存在则抛出异常。
    // 如果@Autowired自动装配的环境比较复杂，自动装配无法通过一个注解【@Autowired】完成的时候，我们可以使用
    // @Qualifier(value = "属性名")来指定需要装配的bean。
    @Autowired
    public DeptLogServiceImpl(DeptLogMapper deptLogMapper) {
        this.deptLogMapper = deptLogMapper;
    }



    // propagation 属性：
    // 用于设置事务的传播行为，它决定着当一个事务方法被另一个事务方法调用时如何使用事务。
    // REQUIRES_NEW：
    // 表示当前方法必须运行在它自己的事务中。一个新的事务将被启动。
    // 如果当前存在一个事务，在该方法执行期间，当前事务会被挂起。
    // 如果使用JTA事务管理，则需要访问事务管理器。
    // 如果使用的是JDBC事务管理，则需要访问数据源。
    // REQUIRES_NEW 要求每次都开启新的事务，如果当前存在事务，则挂起当前事务，开启新
    // 的事务。
    // 默认方法是 REQUIRED —— 加入当前的事务
    // 事务中，如果当前没有事务，就新建一个事务。这是最常见的选择。
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public void insert(DeptLog deptLog) {
        deptLogMapper.insert(deptLog);
    }
}