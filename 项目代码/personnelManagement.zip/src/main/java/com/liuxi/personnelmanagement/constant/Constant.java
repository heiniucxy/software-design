package com.liuxi.personnelmanagement.constant;

/**
 * 常量类
 */
public class Constant {

}
