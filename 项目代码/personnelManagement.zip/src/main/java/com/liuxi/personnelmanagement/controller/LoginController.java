package com.liuxi.personnelmanagement.controller;

import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.Empcredentialsview;
import com.liuxi.personnelmanagement.pojo.Result;
import com.liuxi.personnelmanagement.service.EmpService;
import com.liuxi.personnelmanagement.service.EmpcredentialsviewService;
import com.liuxi.personnelmanagement.utils.JwtUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 蒲月理想
 */
@Slf4j
@RestController
public class LoginController {

    // 用户登录时
    // 1. 用户输入账号密码
    // 2. 调用service层，service层调用mapper层，查询数据库，生成JWT令牌
    // 3. 返回结果
    // 4. 返回结果给前端
    private final  EmpService empService;
    // 用户修改用户信息时：修改用户名和用户密码
    // 1. 用户输入账号密码(和校验密码）
    // 2. 调用service层，service层调用mapper层，修改数据库
    // 3. 修改JWT令牌，返回结果给前端
    private final EmpcredentialsviewService empcredentialsviewService;
    // 构造器注入方式
    @Autowired
    public LoginController(EmpService empService, EmpcredentialsviewService empcredentialsviewService) {
        this.empService = empService;
        this.empcredentialsviewService = empcredentialsviewService;
    }

    /**
     * 管理员登录
     * @param emp
     * @return
     */
    @PostMapping("/login")
    public Result login(@RequestBody Emp emp){
        log.info("管理员登录: {}", emp);
        Emp e = empService.login(emp);
        // 如果为null，返回用户密码错误
        if(e == null){
            return Result.error("用户名或密码错误");
        }
//         检查权限，如果为非管理员，不可登录：设置在拦截器处
        if(e.getEmployeeAuthority() != 1){
            return Result.error("权限不足");
        }

        //登录成功,生成令牌,下发令牌
        return generateJwt(e);

        //登录失败, 返回错误信息
    }
    /**
     * 用户登录
      */

    @PostMapping("/user/login")
    public Result userLogin(@RequestBody Emp emp){
        log.info("用户登录: {}", emp);
        Emp e = empService.login(emp);
        if(e == null){
            return Result.error("用户名或密码错误");
        }
//登录成功,生成令牌,下发令牌
        return generateJwt(e);
     
    }
    /**
     * 用户修改密码
     * @param emp
     */

    @PostMapping("/update")
    public Result updatePassword(@RequestBody Empcredentialsview emp) {
        log.info("用户修改用户名和密码: {}", emp);
        // 首先查询用户名是否重复
        Emp result = empService.findByUsername(emp.getUsername());
        if(result != null &&!result.getId().equals(emp.getId())){
            return Result.error("用户名已存在,请更换用户名");
        }
        empcredentialsviewService.updatePassword(emp);
        // 查询用户
        Emp e = empService.getById(emp.getId());
        /*
         生成JWT令牌，将用户ID和其他信息作为claims
         返回JWT令牌信息给前端
        */
        return generateJwt(e);
    }

    /**
     * 用户忘记密码
     */
    @PostMapping("/reset-password")
    public Result resetPassword(@RequestBody Emp emp){
        log.info("密码重置: {}", emp);
        Emp e = empService.selectByName(emp);
        // 如果为null，返回用户密码错误
        if(e == null){
            return Result.error("用户不存在");
        }
        //存在则更新用户的密码
        // 将Emp转换为Empcredentialsview
        emp.setId((e.getId()));
        Empcredentialsview emp1 = new Empcredentialsview();
        BeanUtils.copyProperties(emp, emp1);
        empcredentialsviewService.updatePassword(emp1);
        return Result.success();
    }

    /**
     * 生成JWT令牌，代码复用
     * @param e
     * @return
     */
    public Result generateJwt(Emp e) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", e.getId());
        claims.put("name", e.getName());
        claims.put("username", e.getUsername());
        claims.put("authority", e.getEmployeeAuthority());
        claims.put("image", e.getImage());
        // 生成JWT令牌，将用户ID和其他信息作为claims
        String jwt = JwtUtils.generateJwt(claims);

        // 将JWT令牌和用户ID一起返回给前端
        Map<String, Object> response = new HashMap<>();
        response.put("jwt", jwt);
        response.put("userId", e.getId());
        response.put("userImage",e.getImage());
        response.put("userAuthority",e.getEmployeeAuthority());
        // 返回包含JWT令牌和用户ID的结果给前端
        log.info("response: {}",response);
       return Result.success(response);
    }

}
