package com.liuxi.personnelmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author 蒲月理想
 */
@SpringBootApplication
public class PersonnelManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(PersonnelManagementApplication.class, args);
    }

}
