package com.liuxi.personnelmanagement.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 员工实体类
 * @author 蒲月理想
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Emp {
    // 员工头像默认和用户名初始为相同值（默认）
    //ID
    private Integer id;
    //用户名
    private String username;
    //密码
    private String password;
    //姓名
    private String name;
    //性别 , 1 男, 2 女
    private Short gender;
    // 婚姻状态
    private Short maritalStatus;
    //头像url
    private String image;
    //职位
    private Short job;
    //入职日期
    private LocalDate entrydate;
    // 离职日期
    //private LocalDate leaveDate;
    // 员工状态
    private Short employeeStatus;
    //部门ID
    private Integer deptId;
    // 部门名称
    private String deptName;
    //创建时间
    private LocalDateTime createTime;
    //修改时间
    private LocalDateTime updateTime;
    // 员工权限
    private Short employeeAuthority;

    // 添加上统计数据所用信息
    // 员工性别数目：
    private Integer genderNumber;
}
