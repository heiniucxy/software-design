package com.liuxi.personnelmanagement.service;

import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.Empcredentialsview;

/**
 * @author 蒲月理想
 */
public interface EmpcredentialsviewService {
    void updatePassword(Empcredentialsview emp);

    Emp login(Empcredentialsview emp);
}
