package com.liuxi.personnelmanagement.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.Map;

/**
 * JWT工具类
 * @author 蒲月理想
 */
public class JwtUtils {

    // Sign Key : 作用是对JWT进行签名，防止JWT被篡改
    // 签名算法，HS256使用SHA256算法
    private static final String SIGN_KEY = "xinlili";
    private static final SignatureAlgorithm SIGNATURE_ALGORITHM = SignatureAlgorithm.HS256;

    // 过期时间 5天
    // 过期时间，这个值应该设置的比实际请求过期时间少30秒，设置过长会出现Token过期问题
    private static final Long EXPIRE = 43200000L;


    /**
     * 生成JWT令牌
     * @param claims JWT第二部分负载 payload 中存储的内容
     * @return
     */
    public static String generateJwt(Map<String, Object> claims){
        return Jwts.builder()
                .addClaims(claims)
                .signWith(SIGNATURE_ALGORITHM, SIGN_KEY)
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRE))
                .compact();
    }

    /**
     * 解析JWT令牌
     * @param jwt JWT令牌
     * @return JWT第二部分负载 payload 中存储的内容
     */
    public static Claims parseJWT(String jwt){
        return Jwts.parser()
                .setSigningKey(SIGN_KEY)
                .parseClaimsJws(jwt)
                .getBody();
    }
}
