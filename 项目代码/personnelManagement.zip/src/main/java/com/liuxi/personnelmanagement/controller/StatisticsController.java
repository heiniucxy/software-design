package com.liuxi.personnelmanagement.controller;

import com.liuxi.personnelmanagement.anno.Log;
import com.liuxi.personnelmanagement.pojo.*;
import com.liuxi.personnelmanagement.service.DeptService;
import com.liuxi.personnelmanagement.service.EmpService;
import com.liuxi.personnelmanagement.service.SalaryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 蒲月理想
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class StatisticsController {
    private final SalaryService salaryService;
    private  final EmpService employeeService;
    private final DeptService departmentService;

    /**
     * 查询员工男女分布情况
     * {},
     */
    @GetMapping("/emp-report/gender")
    public Result getGenderNumber(){
        log.info("查询员工男女分布");
        // 女性female，男性male
        Map<String, Object> response = new HashMap<>();
        // 调用方法获取返回结果
        List<Emp> empList = employeeService.getGenderNumber();
        for(Emp emp : empList){
            // 男性
            if(emp.getGender() == 1){
                response.put("male", emp.getGenderNumber());
            } // 女性
            else if(emp.getGender() == 2){
                response.put("female", emp.getGenderNumber());
            }
        }
        log.info("查询员工男女分布情况成功{}",response);
        return Result.success(response);
    }
    /**
     * 查询部门员工数量
     * {},
     */
    @GetMapping("/emp-report/deptNumber")
    public Result getDeptNumber(){
        log.info("查询部门员工数量");
        List<Dept> deptList = departmentService.numberOfDepartmentEmployees();
        Map<String, Object> response = new HashMap<>();
        for(Dept dept : deptList){
            response.put(dept.getName(), dept.getEmployeeCount());
        }
        log.info("查询部门员工数量成功{}",response);

        return Result.success(response);

    }
    /**
     * 查询薪资分布的情况
     * {},
     */
    @GetMapping("/salary-report/averageSalary")
    public Result getAverageSalary(){
        log.info("查询平均薪资情况");
        Map<String, Object> response = new HashMap<>();
        // 获取薪资时将薪资升序排列，第一个是最小值，最后一个是最大值，根据下标求位置
        List<Salary> salaryList = salaryService.getAllSalary();
        // 求出最大值(maximum)，最小值(minimum)，中位数(median)，下四分之一点(q1)，上四分之一点（q3）
        // 排序薪资列表
       // Collections.sort(salaryList);

// 获取列表长度
        int size = salaryList.size();

// 求最小值和最大值
        Double minimum = salaryList.get(0).getTotalSalary();
        Double maximum = salaryList.get(size - 1).getTotalSalary();

// 求中位数
        Double median;
        if (size % 2 == 1) {
            median = salaryList.get(size / 2).getTotalSalary();
        } else {
            double middle = (size / 2.0);
            median = (salaryList.get((int) Math.floor(middle)).getTotalSalary() + salaryList.get((int) Math.ceil(middle)).getTotalSalary()) / 2;
        }

// 求下四分之一点（q1）和上四分之一点（q3）
        int mid = size / 2;
        Double q1, q3;
        if (size % 2 == 1) {
            q1 = salaryList.get(mid / 2).getTotalSalary();
            q3 = salaryList.get(mid + mid / 2 + 1).getTotalSalary();
        } else {
            q1 = (salaryList.get(mid / 2 - 1).getTotalSalary() + salaryList.get(mid / 2).getTotalSalary()) / 2;
            q3 = (salaryList.get(mid + mid / 2 - 1).getTotalSalary() + salaryList.get(mid + mid / 2).getTotalSalary()) / 2;
        }
        // 放入response中；
        response.put("maximum", maximum);
        response.put("minimum", minimum);
        response.put("median", median);
        response.put("q1", q1);
        response.put("q3", q3);
        log.info("查询部门的薪资分布：{}",response);
        return  Result.success(response);
    }
    /**
     * 统计部门的平均薪资情况：
     */
    @GetMapping("/salary-report/deptSalary")
    public Result getDeptSalary() {
        log.info("查询部门的平均薪资");
        List<Dept> deptList = departmentService.getDeptSalary();
        // 应该使用DTO获取数据来传输，将DTO转为VO返回，或者DTO转为PO保存到数据库中，
        // 此处是一个完善点（在登录中，在薪资的查询中，在数据统计中，在管理中可以再拆分
        Map<String, Object> response = new HashMap<>();
        // 获取部门列表和平均薪资
        for(Dept dept : deptList)
        {
            response.put(dept.getName(),dept.getAvgSalary());
        }
        log.info("查询部门的平均薪资完成,{}", response);
        return Result.success(response);
    }


}
