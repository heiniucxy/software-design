package com.liuxi.personnelmanagement.service;

import com.liuxi.personnelmanagement.pojo.DeptLog;

/**
 * @author 蒲月理想
 */
public interface DeptLogService {

    void insert(DeptLog deptLog);
}
