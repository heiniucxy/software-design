package com.liuxi.personnelmanagement.service;

import com.liuxi.personnelmanagement.pojo.Dept;
import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.PageBean;
import com.liuxi.personnelmanagement.pojo.Salary;

import java.time.LocalDate;
import java.util.List;
/**
 * @author 蒲月理想
 */
public interface SalaryService {
    /**
     * 查询全部工资数据
     * @return List of all dept
     */
   // List<Salary> list();


    PageBean page(Integer page, Integer pageSize, String name, Short gender, Double totalSalary);

    /**
     * 查询单个人的工资
     * @return Salary
     */
    Salary getSalaryById(Integer id);

    // 薪资不设置删除和新增

    /**
     * 更新薪资
     * @param salary
     */
    void update(Salary salary);

    void save(short job,Integer id);

    /**
     * 查询所有薪资
     * @return
     */
    List<Salary> getAllSalary();


}
