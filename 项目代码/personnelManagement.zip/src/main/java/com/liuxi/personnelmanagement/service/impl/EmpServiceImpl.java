package com.liuxi.personnelmanagement.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.liuxi.personnelmanagement.mapper.EmpMapper;
import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.PageBean;
import com.liuxi.personnelmanagement.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author 蒲月理想
 */
@Service
public class EmpServiceImpl implements EmpService {

    private final EmpMapper empMapper;
    // 盐值，用于混交加密
    private static final String SALT = "liuxi";
    @Autowired
    public EmpServiceImpl(EmpMapper empMapper) {
        this.empMapper = empMapper;
    }




    /*@Override
    public PageBean page(Integer page, Integer pageSize) {
        //1. 获取总记录数
        Long count = empMapper.count();

        //2. 获取分页查询结果列表
        Integer start = (page - 1) * pageSize;
        List<Emp> empList = empMapper.page(start, pageSize);

        //3. 封装PageBean对象
        PageBean pageBean = new PageBean(count, empList);
        return pageBean;
    }*/

    /**
     * 分页查询员工列表
     * @param page
     * @param pageSize
     * @param name
     * @param gender
     * @param begin
     * @param end
     * @return
     */
    @Override
    public PageBean page(Integer page, Integer pageSize, String name, Short gender, Short maritalStatus, Short employeeStatus, Short job, Integer deptId, LocalDate begin, LocalDate end) {
        //1. 设置分页参数
        PageHelper.startPage(page,pageSize);
        //2. 执行查询
        List<Emp> empList = empMapper.list(name,gender,maritalStatus,employeeStatus,job,deptId,begin,end);

        Page<Emp> p = (Page<Emp>) empList;
        //3. 封装PageBean对象
        return new PageBean(p.getTotal(), p.getResult());
    }

    /**
     * 批量删除员工
     * @param ids
     */
    @Override
    public void delete(List<Integer> ids) {
        empMapper.delete(ids);
    }

    @Override
    public int save(Emp emp) {
        emp.setCreateTime(LocalDateTime.now());
        emp.setUpdateTime(LocalDateTime.now());
       //  对密码进行加密，初始密码是123456,为其加盐SALT
        String pwd = DigestUtils.md5DigestAsHex(("123456" + SALT).getBytes());
        emp.setPassword(pwd);
        // 检查权限是否为空：
        if(emp.getEmployeeAuthority() == null){
            // 如果为空设置为普通用户
            emp.setEmployeeAuthority((short) 2);
        }
        empMapper.insert(emp);
        // System.out.println("id=" + id);
        return emp.getId();
    }

    @Override
    public Emp getById(Integer id) {
        return empMapper.getById(id);
    }

    @Override
    public void update(Emp emp) {
        emp.setUpdateTime(LocalDateTime.now());

        empMapper.update(emp);
    }

    @Override
    public Emp login(Emp emp) {
        // 对密码进行加密后进行对比
        emp.setPassword(DigestUtils.md5DigestAsHex((emp.getPassword() + SALT).getBytes()));
        return empMapper.getByUsernameAndPassword(emp);
    }

    @Override
    public List<Emp> getGenderNumber() {
     return empMapper.getGenderNumber();
    }

    @Override
    public Emp findByUsername(String username) {
        return empMapper.findByUsername(username);
    }

    /**
     * 根据用户名和真实姓名查询用户
     * @param emp
     * @return
     */
    @Override
    public Emp selectByName(Emp emp) {
       return empMapper.selectByName(emp);
    }
}
