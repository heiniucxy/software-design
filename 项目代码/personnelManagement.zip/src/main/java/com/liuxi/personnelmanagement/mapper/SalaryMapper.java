package com.liuxi.personnelmanagement.mapper;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.PageBean;
import com.liuxi.personnelmanagement.pojo.Salary;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 薪资管理
 * @author 蒲月理想
 */
@Mapper
public interface SalaryMapper {

    /**
     *
     * 查询全部员工薪资信息
     *  return {@link Salary}
     */


//        @Select("SELECT s.*, e.name, e.gender, e.image, e.job FROM salary s " +
//                "JOIN emp e ON s.emp_id = e.id")
        List<Salary>list(
                @Param("name") String name,
                @Param("gender") Short gender,
                @Param("totalSalary") Double totalSalary
        );

    @Select(" select s.*, e.name, e.gender, e.image, e.job," +
            "        (s.basic_salary + s.merit_salary + s.bonus_salary + s.subsidy_salary) as total_salary" +
            "        from salary s JOIN emp e ON e.id = s.emp_id where e.id = #{id} ")
    Salary getSalaryById(Integer id);

    /**
     * 更新工资
     * @param salary
     */
//    @Update(("update salary set basic_salary = #{basicSalary},merit_salary = #{meritSalary},bonus_salary = #{bonusSalary},subsidy_salary = #{subsidySalary}=#{subsidySalary} " +
//            "where id = #{id}"))
    void updateById(Salary salary);

    /**
     * 保存薪资
     * @param salary
     */
    void save(Salary salary);

    /**
     * 查询所有薪资,并且升序排列
     * @return
     */
    @Select("select *,(salary.basic_salary+salary.merit_salary+salary.subsidy_salary+salary.bonus_salary) as total_salary from salary order by total_salary ")
    List<Salary> getAllSalary();
}
