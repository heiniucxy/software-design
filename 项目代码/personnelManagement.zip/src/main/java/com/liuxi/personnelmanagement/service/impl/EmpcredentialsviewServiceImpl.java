package com.liuxi.personnelmanagement.service.impl;

import com.liuxi.personnelmanagement.mapper.EmpcredentialsviewMapper;
import com.liuxi.personnelmanagement.pojo.Emp;
import com.liuxi.personnelmanagement.pojo.Empcredentialsview;
import com.liuxi.personnelmanagement.service.EmpcredentialsviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;


/**
 * @author 蒲月理想
 */
@Service
@RequiredArgsConstructor
public class EmpcredentialsviewServiceImpl implements EmpcredentialsviewService {

    private static final String SALT = "liuxi";
    private final EmpcredentialsviewMapper empcredentialsviewMapper;
    /**
     * 更新用户名和密码
     * @param emp
     */
    @Override
    public void updatePassword(Empcredentialsview emp) {
        //对密码进行加密后保存
       String pwd = DigestUtils.md5DigestAsHex((emp.getPassword() + SALT).getBytes());
       emp.setPassword(pwd);

        // 更新
        empcredentialsviewMapper.update(emp);
    }

    @Override
    public Emp login(Empcredentialsview emp) {
        return empcredentialsviewMapper.login(emp);
    }
}
