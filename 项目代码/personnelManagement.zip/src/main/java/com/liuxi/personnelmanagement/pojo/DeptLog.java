package com.liuxi.personnelmanagement.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 部门操作日志
 * @author 蒲月理想
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeptLog {
    // 部门的id
    private Integer id;
    // 创建时间
    private LocalDateTime createTime;
    // 操作描述
    private String description;
}
