package com.liuxi.personnelmanagement.service;


import com.liuxi.personnelmanagement.pojo.Dept;

import java.util.List;

/**
 * 部门管理
 * @author 蒲月理想
 */
public interface DeptService {
    /**
     * 查询全部部门数据
     * @return List of all dept
     */
    List<Dept> list();

    /**
     * 查询单个部门
     * @return dept
     */
   Dept getDeptById(Integer id);


    /**
     * 删除部门
     * @param id
     */
    void delete(Integer id);

    /**
     * 新增部门
     * @param dept
     */
    void add(Dept dept);

    /**
     * 更新部门
     * @param dept
     */
    void update(Dept dept);

    /**
     * 查询部分人数
     * @return
     */

    List<Dept> numberOfDepartmentEmployees();

    /**
     * 查询部门平均薪资
     * @return
     */
    List<Dept> getDeptSalary();

    Dept findByName(String name);


    Dept getByName(String name);
}
