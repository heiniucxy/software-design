package com.liuxi.personnelmanagement.mapper;

import com.liuxi.personnelmanagement.pojo.Dept;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * 部门管理
 * @author 蒲月理想
 */
@Mapper
public interface DeptMapper {
    /**
     * 查询全部部门
     * @return
     */
    @Select("select * from dept")
    List<Dept> list();

    /**
     * 根据ID删除部门
     * @param id
     */
    @Delete("delete from dept where id = #{id}")
    void deleteById(Integer id);

    /**
     * 新增部门
     * @param dept
     */
    @Insert("insert into dept(name, create_time, update_time) values(#{name},#{createTime},#{updateTime})")
    void insert(Dept dept);

    /**
     * 根据Id查询部门
     * @param id
     * @return dept
     */
    @Select(("select * from dept where id = #{id}"))
    Dept getByDeptId(Integer id);

    /**
     * 更新部门
     * @param dept
     */

    @Update("update dept set name = #{name} where id = #{id}")
    void updateById(Dept dept);

    /**
     * 统计每个部门的人数
     * @return
     */
//    @Select(("select d.*,count(*) as employeeCount from dept d join emp e on d.id = e.dept_id" +
//            " group by  d.id"))
    List<Dept> numberOfDepartmentEmployees();

    /**
     * 统计每个部门的平均薪资
     * @return
     */
    List<Dept> getDeptSalary();

    /**
     * 精确查询部门名称是否存在
     * @param name
     * @return
     */
    @Select("select * from dept where name = #{name}")
    Dept findByName(String name);

    /**
     * 模糊查询 部门名称
     * @param name
     * @return
     */
    @Select("select * from dept where name like concat('%',#{name},'%')")
    Dept getByName(String name);
}
