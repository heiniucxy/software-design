package com.liuxi.personnelmanagement.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * @author 蒲月理想
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Salary {

    // 员工工资信息
    //ID
   private Integer id;
    // 员工ID
    private Integer empId;
    // 基本工资
    private Double basicSalary;
    // 绩效工资
    private Double meritSalary;
    // 奖金
    private Double bonusSalary;
    // 补贴
    private Double subsidySalary;
    //创建时间
    private LocalDateTime createTime;
    //修改时间
    @Setter
    private LocalDateTime updateTime;

    //添加员工基本信息：
   //姓名

   private String name;
   //性别 , 1 男, 2 女
   private Short gender;
   //头像url
   private String image;
   //职位
   private Short job;

   // 添加一个员工总工资信息：
    private Double totalSalary;


}
