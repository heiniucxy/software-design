-- 部门管理
create table dept(
    id int unsigned primary key auto_increment comment '主键ID',
    name varchar(10) not null unique comment '部门名称',
    create_time datetime not null comment '创建时间',
    update_time datetime not null comment '修改时间'
) comment '部门表';

insert into dept (id, name, create_time, update_time) values(1,'学工部',now(),now()),(2,'教研部',now(),now()),(3,'咨询部',now(),now()), (4,'就业部',now(),now()),(5,'人事部',now(),now());


#drop table if exists emp;
-- 员工管理(带约束)
create table emp (
  id int unsigned primary key auto_increment comment 'ID',
  username varchar(20) not null unique comment '用户名',
  password varchar(32) default '123456' comment '密码',
  name varchar(10) not null comment '姓名',
  gender tinyint unsigned not null comment '性别, 说明: 1 男, 2 女',
  marital_status tinyint unsigned not null comment '婚姻状况, 说明: 1 未婚, 2 已婚',
#   id_card varchar(18) not null unique comment '身份证号',
#   birthday date not null comment '出生日期',
  image varchar(300) comment '头像',
  job tinyint unsigned comment '职位',
  entrydate date comment '入职时间',
  #leave_date date comment '离职时间',
  employee_status tinyint unsigned comment '状态, 说明: 1 正式员工, 2 非正式员工, 3 离职员工',
  dept_id int unsigned not null comment '部门ID',

  create_time datetime not null comment '创建时间',
  update_time datetime not null comment '修改时间',
  employee_authority tinyint unsigned default '2' comment '权限,说明: 1 管理员, 2 普通员工'
) comment '员工表';
# 给员工表添加外键约束：部门id
alter table emp add constraint fk_emp_dept_id foreign key (dept_id) references dept(id);
# 删除员工表离职日期列：
#alter table emp drop column leave_date;
#修改用户表的用户名可以为重复 默认值为“123456”
#dify column username varchar(20) comment '用户名' default '123456' after id;
# 用户名不能重复
alter table emp modify column username varchar(20) not null unique comment '用户名' after id;
# 修改员工的状态默认为在职员工
alter table emp modify column employee_status tinyint unsigned default '1' comment '状态, 说明: 1 正式员工, 2 非正式员工, 3 离职员工' after employee_authority;
## 部门删除则员工删除：
ALTER TABLE emp
    DROP FOREIGN KEY fk_emp_dept_id;  -- 删除原有外键约束
ALTER TABLE emp
ADD CONSTRAINT fk_emp_dept_id
FOREIGN KEY (dept_id)
REFERENCES dept(id)
ON DELETE CASCADE;  -- 设置级联删除

### 创建视图——用于员工信息的查询和修改：
-- 创建视图以获取员工的用户名和密码
CREATE VIEW EmpCredentialsView AS
SELECT id, username, image,password
FROM emp;

#drop table if exists salary;
# 新建薪资表：
    create table salary(
    id int unsigned primary key auto_increment comment 'ID',
    emp_id int unsigned not null comment '员工ID',
    basic_salary decimal(10,2) comment '基本工资,说明: 精确到两位小数，最高工资到千万，单位是人民币',
    merit_salary decimal(10,2) comment '绩效工资,说明: 精确到两位小数，最高工资到千万，单位是人民币',
    bonus_salary decimal(10,2) comment '奖金,说明: 精确到两位小数，最高工资到千万,单位是人民币',
    subsidy_salary decimal(10,2) comment '补贴,说明: 精确到两位小数，最高工资到千万，单位是人民币',
    create_time datetime not null comment '创建时间',
    update_time datetime not null comment '修改时间',
    foreign key(emp_id) references emp(id)
    )comment '工资表';
# 修改薪资表：薪资默认为0：
alter table salary modify column basic_salary decimal(10,2) default '0' comment '基本工资,说明: 精确到两位小数，最高工资到千万，单位是人民币' after emp_id;
alter table salary modify column merit_salary decimal(10,2) default '0' comment '绩效工资,说明: 精确到两位小数，最高工资到千万，单位是人民币' after basic_salary;
alter table salary modify column bonus_salary decimal(10,2) default '0' comment '奖金,说明: 精确到两位小数，最高工资到千万,单位是人民币' after merit_salary;
alter table salary modify column subsidy_salary decimal(10,2) default '0' comment '补贴,说明: 精确到两位小数，最高工资到千万，单位是人民币' after bonus_salary;
# 级联删除：
ALTER TABLE salary
ADD CONSTRAINT fk_emp_id
FOREIGN KEY (emp_id)
REFERENCES emp(id)
ON DELETE CASCADE;




# 最开始的数据
INSERT INTO emp
	(id, username, password, name, gender, marital_status,image, job, entrydate,dept_id, create_time, update_time) VALUES
	#(1,'jinyong','123456','金庸',1,1,'1.jpg',4,'2000-01-01',2,now(),now()),
	(2,'zhangwuji','123456','张无忌',1,1,'2.jpg',2,'2015-01-01',2,now(),now()),
	(3,'yangxiao','123456','杨逍',1,1,'3.jpg',2,'2008-05-01',2,now(),now()),
	(4,'weiyixiao','123456','韦一笑',1,1,'4.jpg',2,'2007-01-01',2,now(),now()),
	(5,'changyuchun','123456','常遇春',1,1,'5.jpg',2,'2012-12-05',2,now(),now()),
	(6,'xiaozhao','123456','小昭',2,1,'6.jpg',3,'2013-09-05',1,now(),now()),
	(7,'jixiaofu','123456','纪晓芙',2,1,'7.jpg',1,'2005-08-01',1,now(),now()),
	(8,'zhouzhiruo','123456','周芷若',2,1,'8.jpg',1,'2014-11-09',1,now(),now()),
	(9,'dingminjun','123456','丁敏君',2,1,'9.jpg',1,'2011-03-11',1,now(),now()),
	(10,'zhaomin','123456','赵敏',2,1,'10.jpg',1,'2013-09-05',1,now(),now()),
	(11,'luzhangke','123456','鹿杖客',1,1,'11.jpg',5,'2007-02-01',3,now(),now()),
	(12,'hebiweng','123456','鹤笔翁',1,1,'12.jpg',5,'2008-08-18',3,now(),now()),
	(13,'fangdongbai','123456','方东白',1,1,'13.jpg',5,'2012-11-01',3,now(),now()),
	(14,'zhangsanfeng','123456','张三丰',1,1,'14.jpg',2,'2002-08-01',2,now(),now()),
	(15,'yulianzhou','123456','俞莲舟',1,1,'15.jpg',2,'2011-05-01',2,now(),now()),
	(16,'songyuanqiao','123456','宋远桥',1,1,'16.jpg',2,'2007-01-01',2,now(),now()),
	(17,'chenyouliang','123456','陈友谅',1,1,'17.jpg',3,'2015-03-21',2,now(),now());



