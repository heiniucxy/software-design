package com.liuxi.personnelmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonnelManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
