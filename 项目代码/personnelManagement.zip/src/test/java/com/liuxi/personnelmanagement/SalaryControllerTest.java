//package com.liuxi.personnelmanagement;
//import com.liuxi.personnelmanagement.controller.SalaryController;
//import com.liuxi.personnelmanagement.pojo.PageBean;
//import com.liuxi.personnelmanagement.service.SalaryService;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
//
//import static org.mockito.ArgumentMatchers.*;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(SpringExtension.class)
//@WebMvcTest(SalaryController.class)
//public class SalaryControllerTest {
//
//    @Autowired
//    private MockMvc mockMvc; // MockMvc实例
//
//    @Mock
//    private SalaryService salaryService; // Mock一个SalaryService实例
//
//    @InjectMocks
//    private SalaryController salaryController; // 实际的SalaryController实例
//
//    @Test
//    void testPage() throws Exception {
//        // 模拟调用salaryService.page方法并返回一些假数据
//        when(salaryService.page(anyInt(), anyInt(), anyString(), anyShort(), anyDouble())).thenReturn(new PageBean());
//
//        mockMvc.perform(MockMvcRequestBuilders.get("/salary")
//                        .param("page", "1")
//                        .param("pageSize", "10")
//                        .param("name", "")
//                        .param("gender", "1")
//                        .param("totalSalary", ""))
//                .andExpect(MockMvcResultMatchers.status().isOk());
//    }
//}